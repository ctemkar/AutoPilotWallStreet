# AutopilotAlpha — System Summary

## Purpose
Single-screen trading terminal (Next.js + React + TypeScript) with autopilot trading, broker proxies, and monitoring. Designed to run on a VPS behind Nginx with PM2.

## Key Components
- Frontend: Next.js App Router in `app/` — main UI in `app/MarketTerminal.tsx` and `app/page.tsx`.
- Ticker Universe: `app/tickerList.ts` defines `quickTickers` scanning universe.
- Broker Proxies: `app/api/alpaca/route.ts` (Alpaca), `app/api/gemini/analyze/route.ts` (AI diagnostics), other provider routes under `app/api/*`.
- Server boot: `server.ts` / `server.js` (optional custom bootstrap).
- Config: `package.json`, `tsconfig.json`, `next.config.mjs`, `postcss.config.mjs`, `tailwind.config.js`.

## Important Behaviors
- Autopilot cooldowns persist to `localStorage` key `sentry:autopilotCooldowns` to prevent rapid re-entry after liquidations.
- External broker position closes are detected during the refresh loop and will arm per-symbol cooldowns.
- Alpaca proxy returns normalized `positions` and `account` objects used by the frontend.
- Gemini analyze endpoint attempts to call Google GenAI; if no `GEMINI_API_KEY` is configured, a local fallback stress matrix is returned.

## Deployment Notes
- Build steps on VPS:

```bash
cd /opt/AutopilotAlpha
npm ci
npm run build
pm2 reload autopilotalpha --update-env
```

- Reverse proxy: Nginx to `127.0.0.1:3000`; use Certbot to obtain TLS cert for domain.

## Files Included in Zip
- `README.md`, `DETAILED_DOCUMENT.md`, `AGENTS.md`, `package.json`, `tsconfig.json`, `next.config.mjs`, `postcss.config.mjs`, `tailwind.config.js`, `server.ts`, `server.js`, `app/MarketTerminal.tsx`, `app/tickerList.ts`, `app/page.tsx`, `app/layout.tsx`, `app/globals.css`, `app/api/alpaca/route.ts`, `app/api/gemini/analyze/route.ts`, and this `SYSTEM_DOC.md`.

## How to Use This Archive
1. Extract on the server or a dev machine.
2. Install dependencies with `npm ci`.
3. Build with `npm run build` and run with `pm2` or `next start`.

## Contact
For changes to the autopilot logic, see `app/MarketTerminal.tsx` and the `OPERATIONAL/` logs for blocked actions and cooldown traces.
